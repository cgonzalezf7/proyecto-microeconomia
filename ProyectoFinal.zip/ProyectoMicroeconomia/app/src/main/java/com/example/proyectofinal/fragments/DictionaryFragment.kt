package com.example.proyectofinal.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.R
import com.example.proyectofinal.activities.WordActivity
import com.example.proyectofinal.adapters.DictionaryAdapter
import com.example.proyectofinal.models.TotalWordsEvent
import com.example.proyectofinal.models.Word
import com.example.proyectofinal.utils.RxBus
import com.example.proyectofinal.interfaces.DictionaryClickListener
import com.example.proyectofinal.utils.toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.*
import kotlinx.android.synthetic.main.fragment_dictionary.view.*
import java.util.EventListener

class DictionaryFragment : Fragment(), DictionaryClickListener {

    private lateinit var _view: View

    private lateinit var viewAdapter: DictionaryAdapter
    private lateinit var viewManager: RecyclerView.LayoutManager
    private val wordList: ArrayList<Word> = ArrayList()

    private val mAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private lateinit var currentUser: FirebaseUser

    private val store: FirebaseFirestore = FirebaseFirestore.getInstance()
    private lateinit var dictionaryDBRef: CollectionReference

    private var dictionarySubscription: ListenerRegistration? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _view = inflater.inflate(R.layout.fragment_dictionary, container, false)

        setUpWordDB()
        setUpCurrentUser()
        subscribeToDictionary()
        setUpRecyclerView()

        return _view
    }

    override fun onDestroyView() {
        dictionarySubscription?.remove()
        super.onDestroyView()
    }

    override fun onDictionaryClickListener(data: Word) {
        val intent = Intent(activity, WordActivity::class.java)
        intent.putExtra(getString(R.string.word_email), data.email)
        intent.putExtra(getString(R.string.word_profile_image_url), data.profileImageURL)
        intent.putExtra(getString(R.string.word_word), data.word)
        intent.putExtra(getString(R.string.word_description), data.description)
        startActivity(intent)
    }

    private fun setUpWordDB() {
        dictionaryDBRef = store.collection(getString(R.string.word_collection))
    }

    private fun setUpCurrentUser() {
        currentUser = mAuth.currentUser!!
    }

    private fun setUpRecyclerView() {
        viewManager = LinearLayoutManager(context)
        viewAdapter = DictionaryAdapter(wordList, this)

        _view.recyclerView.setHasFixedSize(true)
        _view.recyclerView.layoutManager = viewManager
        _view.recyclerView.adapter = viewAdapter
    }

    private fun subscribeToDictionary() {
        dictionarySubscription = dictionaryDBRef
            .orderBy(getString(R.string.word_word), Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener(object : EventListener,
                com.google.firebase.firestore.EventListener<QuerySnapshot> {
                override fun onEvent(snapshot: QuerySnapshot?, exception: FirebaseFirestoreException?) {
                    exception?.let {
                        activity!!.toast(getString(R.string.word_exception))
                        return
                    }
                    snapshot?.let {
                        wordList.clear()
                        val messages = it.toObjects(Word::class.java)
                        wordList.addAll(messages.asReversed())
                        viewAdapter.notifyDataSetChanged()
                        RxBus.publish(TotalWordsEvent(wordList.size))
                    }
                }
            })
    }

}
