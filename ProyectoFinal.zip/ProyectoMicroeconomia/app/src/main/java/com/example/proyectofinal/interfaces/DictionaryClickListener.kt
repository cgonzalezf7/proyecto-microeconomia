package com.example.proyectofinal.interfaces

import com.example.proyectofinal.models.Word

interface DictionaryClickListener {
    fun onDictionaryClickListener(data: Word)
}