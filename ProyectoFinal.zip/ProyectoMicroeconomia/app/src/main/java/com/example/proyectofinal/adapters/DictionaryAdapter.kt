package com.example.proyectofinal.adapters

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.R
import com.example.proyectofinal.utils.inflate
import com.example.proyectofinal.models.Word
import com.example.proyectofinal.utils.CircleTransform
import com.example.proyectofinal.interfaces.DictionaryClickListener
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_dictionary_item.view.*

class DictionaryAdapter(private val items: List<Word>, private val dictionaryClickListener: DictionaryClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val layout = R.layout.fragment_dictionary_item

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        fun bind(word: Word) = with(itemView){
            val position = adapterPosition + 1
            val space = resources.getString(R.string.word_space)
            val wordPosition = position.toString() + space + word.word
            textViewWord.text = wordPosition
            textViewDescription.text = word.description

            if (word.profileImageURL.isEmpty()) {
                Picasso.get().load(R.drawable.ic_account).placeholder(R.drawable.ic_account).resizeDimen(R.dimen.profile_image_size, R.dimen.profile_image_size)
                    .centerCrop().transform(CircleTransform()).into(imageViewProfile)
            } else {
                Picasso.get().load(word.profileImageURL).resizeDimen(R.dimen.profile_image_size, R.dimen.profile_image_size)
                    .centerCrop().transform(CircleTransform()).into(imageViewProfile)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ViewHolder(parent.inflate(layout))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ViewHolder).bind(items[position])

        val data = items[position]
        holder.itemView.setOnClickListener {
            dictionaryClickListener.onDictionaryClickListener(data)
        }
    }

    override fun getItemCount() = items.size

}