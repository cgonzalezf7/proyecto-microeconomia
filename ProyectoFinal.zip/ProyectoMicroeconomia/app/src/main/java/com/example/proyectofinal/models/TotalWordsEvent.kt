package com.example.proyectofinal.models

data class TotalWordsEvent(val total: Int)