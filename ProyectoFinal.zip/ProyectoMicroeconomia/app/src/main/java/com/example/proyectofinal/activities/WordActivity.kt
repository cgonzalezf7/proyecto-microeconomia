package com.example.proyectofinal.activities

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.proyectofinal.R
import com.example.proyectofinal.utils.CircleTransform
import com.example.proyectofinal.utils.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_word.*
import java.util.ArrayList

class WordActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_word)

        setUpActionBar()
        setUpUI(extras())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_activity_word, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.deleteWord -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle(resources.getString(R.string.word_delete_dialog_title))
                    .setMessage(resources.getString(R.string.word_delete_dialog_message))
                    .setNegativeButton(resources.getString(R.string.word_delete_dialog_negative)) { _, _ -> }
                    .setPositiveButton(resources.getString(R.string.word_delete_dialog_positive)) { _, _ ->
                        toast("delete")
                    }
                    .show()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun setUpActionBar() {
        setSupportActionBar(wordToolbar)

        if (supportActionBar != null){
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.setDisplayShowHomeEnabled(true)
            supportActionBar!!.title = getString(R.string.word_word_capital)
        }
    }

    private fun extras(): ArrayList<String> {
        val extras = intent.extras!!
        val array: ArrayList<String>
        val word = extras.getString(getString(R.string.word_word))!!
        val description = extras.getString(getString(R.string.word_description))!!
        val email = extras.getString(getString(R.string.word_email))!!
        val image = extras.getString(getString(R.string.word_profile_image_url))!!

        array = arrayListOf(word, description, email, image)
        return array
    }

    private fun setUpUI(data: ArrayList<String>) {
        textViewWord.text = data[0]
        textViewDescription.text = data[1]
        textViewAuthorEmail.text = data[2]
        if (data[3].isEmpty()) {
            Picasso.get().load(R.drawable.ic_account).placeholder(R.drawable.ic_account).resizeDimen(R.dimen.word_profile_image_size, R.dimen.word_profile_image_size)
                .centerCrop().transform(CircleTransform()).into(imageViewProfile)
        } else {
            Picasso.get().load(data[3]).resizeDimen(R.dimen.word_profile_image_size, R.dimen.word_profile_image_size)
                .centerCrop().transform(CircleTransform()).into(imageViewProfile)
        }

    }
}